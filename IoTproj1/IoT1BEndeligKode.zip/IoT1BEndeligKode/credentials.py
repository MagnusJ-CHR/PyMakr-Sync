# Python dictionary {} der indeholder login oplysninger
# Undlad at uploade denne fil til github når den er udfyldt

# ADAFRUIT_IO_URL behøves ikke at ændres

# ADAFRUIT_IO_FEEDNAME behøves ikke at ændres (men skal oprettes med samme navn)
# men der skal oprettes en feed med samme navn på adafruit.io

credentials = {
    'ssid' : 'Gruppe1IOT',
    'password' : 'IOTGruppe1',
    'ADAFRUIT_IO_URL' : b'io.adafruit.com',
    'ADAFRUIT_USERNAME' : b'oqoqo',
    'ADAFRUIT_IO_KEY' : b'aio_nrVv10Kt6YRdpkIrR8xemm9bNQZc',
    'ADAFRUIT_IO_FEEDNAME' : b'iotproj-1'
    }